﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1;


namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        private store7Entities categories = new store7Entities();
        private store7Entities orders = new store7Entities();
        private store7Entities products = new store7Entities();

        public MainWindow()
        {
            InitializeComponent();

            gridCategories.ItemsSource = categories.Categories.ToList();
            gridOrders.ItemsSource = orders.Orders.ToList();
            gridProducts.ItemsSource = products.Products.ToList();

        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TabItem selectedTab = (sender as TabControl)?.SelectedItem as TabItem;
            switch (selectedTab?.Header)
            {
                case "Categories":
                    grid_store7.ItemsSource = categories.Categories.ToList();
                    break;
                case "Orders":
                    grid_store7.ItemsSource = orders.Orders.ToList();
                    break;
                case "Products":
                    grid_store7.ItemsSource = products.Products.ToList();
                    break;
            }
        }
    }
}
